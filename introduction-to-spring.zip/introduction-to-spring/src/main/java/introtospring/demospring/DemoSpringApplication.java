package introtospring.demospring;

import components.ConsoleRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import repositories.UserRepository;
import services.UserService;
import services.UserServiceImpl;

@SpringBootApplication
public class DemoSpringApplication {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(DemoSpringApplication.class, args);


    }

}
