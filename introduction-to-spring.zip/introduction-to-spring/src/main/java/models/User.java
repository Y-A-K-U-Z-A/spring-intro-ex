package models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "users")
@NoArgsConstructor
public class User {
    @Id @Getter
    @Setter
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Getter
    @Setter
    @Column(name = "username", unique = true)
    private String username;
    @Getter
    @Setter
    @Column
    private int age;
    @Getter
    @Setter
    @OneToMany
    @JoinColumn(referencedColumnName = "id")
    private Set<Account> accounts;
}
