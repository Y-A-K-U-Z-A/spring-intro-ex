package repositories;

import models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    User save(User user);
    User findOneById (long id);
    List<User> findAll();
    long count();
    void delete(User user);
    boolean existsUser(long id);
    User getByUsername(String username);
}
