package repositories;

import models.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Account save(Account account);
    Account findOne(long id);
    List<Account> findAll();
    long count();
    void delete(Account account);
    boolean exists(long id);
}
