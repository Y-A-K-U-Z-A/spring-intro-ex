package components;

import models.Account;
import models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import services.AccountService;
import services.UserService;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class ConsoleRunner implements CommandLineRunner {
    private UserService userService;
    private AccountService accountService;

    @Autowired
    public ConsoleRunner(UserService userService, AccountService accountService){
        this.userService = userService;
        this.accountService = accountService;
    }


    @Override
    public void run(String... args) throws Exception {
        User user = new User();
        user.setUsername("Yoavana");
        user.setAge(20);
        user.setId(1);
        userService.registerUser(user);


        Account account = new Account();
        account.setBalance(BigDecimal.valueOf(2000));
        account.setId(1);
        account.setUser(user);
        Account account1 = new Account();
        account1.setId(2);
        account1.setUser(user);
        account1.setBalance(BigDecimal.valueOf(3000));

        HashSet<Account> accounts1 = new HashSet<>();
        accounts1.add(account);
        accounts1.add(account1);
        user.setAccounts(accounts1);

        User user1 = new User();
        user1.setId(2);
        user1.setAge(35);
        user1.setUsername("Ivaylolo");
        userService.registerUser(user1);

        Account account2 = new Account();
        account2.setId(3);
        account2.setBalance(BigDecimal.valueOf(100));

        Set<Account> accounts2 = new HashSet<>();
        accounts2.add(account2);
        user1.setAccounts(accounts2);

        Set<Account> accounts = user.getAccounts();
        BigDecimal money = new BigDecimal(0);
        for (Account acc : accounts) {
            money.add(acc.getBalance());
            accountService.withdrawMoney(BigDecimal.valueOf(100), acc.getId());
        }
        System.out.println(user.getUsername() + " $" + money);

        System.out.println();
        accountService.transferMoney(BigDecimal.valueOf(15), user1.getId(), user.getId());
        BigDecimal decimal = new BigDecimal(0);
        for (Account accoun : user.getAccounts()) {
            decimal.add(accoun.getBalance());
        }
        System.out.println(user.getUsername() + " $" + decimal );
        System.out.println();
        System.out.println(user1.getUsername() + " $" + account2.getBalance());


    }
}
