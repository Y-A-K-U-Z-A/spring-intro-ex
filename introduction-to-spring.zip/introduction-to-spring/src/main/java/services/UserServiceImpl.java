package services;

import models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repositories.UserRepository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

@Service
public class UserServiceImpl implements UserService{
    private final UserRepository userRepository;
    private final EntityManagerFactory entityManagerFactory;
    private final EntityManager entityManager;

    @Autowired
    public UserServiceImpl(UserRepository userRepository){
        this.userRepository = userRepository;
        entityManagerFactory = Persistence.createEntityManagerFactory("spring");
        this.entityManager = entityManagerFactory.createEntityManager();
    }


    @Override
    public void registerUser(User user) {
        entityManager.persist(user);
    }
}
