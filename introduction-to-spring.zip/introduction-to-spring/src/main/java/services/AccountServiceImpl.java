package services;

import models.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repositories.AccountRepository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;

@Service
public class AccountServiceImpl implements AccountService{
    private final AccountRepository accountRepository;
    private final EntityManagerFactory entityManagerFactory;
    private final EntityManager entityManager;

    @Autowired
    public AccountServiceImpl(AccountRepository accountRepository){
        this.accountRepository = accountRepository;
        entityManagerFactory = Persistence.createEntityManagerFactory("spring");
        this.entityManager = entityManagerFactory.createEntityManager();
    }

    @Override
    public void withdrawMoney(BigDecimal money, Long id) {
        Account account;
        if (accountRepository.exists(id)){
            account = accountRepository.findOne(id);
        }else {
            throw new IllegalArgumentException("No such id exists.");
        }
        BigDecimal newBalance = account.getBalance().subtract(money);
        try{
        if (account.getBalance().compareTo(newBalance) > 0 ){
            entityManager.getTransaction().begin();
            account.setBalance(newBalance);
            entityManager.persist(account);
            entityManager.getTransaction().commit();
        }else {
            throw new IllegalStateException();
        }}catch (IllegalStateException e){
            entityManager.getTransaction().rollback();
            System.out.println("No enough money in balance.");
        }
    }

    @Override
    public void transferMoney(BigDecimal money, Long idSender, Long idRecipient) {
        Account sender;
        Account recipient;
        if (accountRepository.exists(idSender) && accountRepository.exists(idRecipient)){
            sender = accountRepository.findOne(idSender);
            recipient = accountRepository.findOne(idRecipient);
        }else {
            throw new IllegalArgumentException("No such id exists.");
        }

        BigDecimal newBalance = sender.getBalance().subtract(money);
        try{if (sender.getBalance().compareTo(newBalance) > 0){
            entityManager.getTransaction().begin();
            sender.setBalance(newBalance);
            recipient.setBalance(recipient.getBalance().add(money));
            entityManager.persist(sender);
            entityManager.persist(recipient);
            entityManager.getTransaction().commit();
        }else {
            throw new IllegalStateException();
        }}catch (IllegalStateException e){
            entityManager.getTransaction().rollback();
            System.out.println("No enough money in balance.");
        }
    }
}
