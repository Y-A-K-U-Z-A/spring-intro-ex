package com.softuni.springintroexercise.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD;
}
