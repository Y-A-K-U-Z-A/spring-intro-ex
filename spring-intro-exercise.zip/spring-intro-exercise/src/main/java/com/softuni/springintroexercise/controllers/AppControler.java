package com.softuni.springintroexercise.controllers;

import com.softuni.springintroexercise.entities.Book;
import com.softuni.springintroexercise.services.AuthorService;
import com.softuni.springintroexercise.services.BookService;
import com.softuni.springintroexercise.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class AppControler implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    @Autowired
    public AppControler(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
//        this.categoryService.seedCategories();
//        this.authorService.seedAuthors();
//        this.bookService.seedBooks();

        //ex 1
        // this.bookService.getAllBooksAfter2000().forEach(e-> System.out.println(e.getTitle()));

        // ex 3
        this.authorService.getAuthorsByCount().forEach(e -> System.out.println(e.getFirstName() + " " + e.getFirstName() + " " + e.getBooks().size()));

    }
}
