package com.softuni.springintroexercise.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
