package com.softuni.springintroexercise.services.impl;

import com.softuni.springintroexercise.constants.GlobalConstants;
import com.softuni.springintroexercise.entities.*;
import com.softuni.springintroexercise.repositories.BookRepository;
import com.softuni.springintroexercise.services.AuthorService;
import com.softuni.springintroexercise.services.BookService;
import com.softuni.springintroexercise.services.CategoryService;
import com.softuni.springintroexercise.utils.FileUtil;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
@Transactional
public class BookServiceImpl implements BookService {
    private final BookRepository repository;
    private final FileUtil fileUtil;
    private final AuthorService authorService;
    private final CategoryService categoryService;

    public BookServiceImpl(BookRepository repository, FileUtil fileUtil, AuthorService authorService, CategoryService categoryService) {
        this.repository = repository;
        this.fileUtil = fileUtil;
        this.authorService = authorService;
        this.categoryService = categoryService;
    }

    @Override
    public void seedBooks() throws IOException {
        String[] fileContent = this.fileUtil.readFileContent(GlobalConstants.BOOK_FILE_PATH);
        Arrays.stream(fileContent).forEach(e -> {
            String[] array = e.split("\\s+");

            int editionType = Integer.parseInt(array[0]);
            LocalDate releasedDate = getReleasedDate(array[1]);
            int copies = Integer.parseInt(array[2]);
            BigDecimal price = BigDecimal.valueOf(Double.parseDouble(array[3]));
            int ageRestriction = Integer.parseInt(array[4]);
            Set<Category> categories = getRandomCategories();
            Book book = createBook(releasedDate, copies, price, ageRestriction, editionType, setTitle(array), categories);
            repository.saveAndFlush(book);

        });
    }

    @Override
    public List<Book> getAllBooksAfter2000() {
        LocalDate releasedDate = LocalDate.of(2000,12, 30);
        return this.repository.findAllByReleasedDateAfter(releasedDate);
    }



    private Set<Category> getRandomCategories() {
        Random random = new Random();
        int bound = random.nextInt(3) + 1;
        Set<Category> categories = new HashSet<>();

        for (int i = 1; i <= bound; i++) {
            int categoryId = random.nextInt(8)+1;
            categories.add(this.categoryService.getCategoryById(categoryId));
        }
        return categories;
    }

    private String setTitle(String[] array) {
        String title = "";
        for (int i = 5; i < array.length; i++) {
            title += array[i] + " ";
        }
        return title;
    }

    private Book createBook(LocalDate releasedDate, int copies, BigDecimal price, int ageRestriction, int editionType, String title, Set<Category> categories) {
        Book book = new Book();
        EditionType[] values = EditionType.values();
        book.setAuthor(getRandomAuthor());
        book.setEditionType(values[editionType]);
        book.setReleasedDate(releasedDate);
        book.setCopies(copies);
        book.setPrice(price);
        AgeRestriction[] values1 = AgeRestriction.values();
        book.setAgeRestriction(values1[ageRestriction]);
        book.setTitle(title);
        book.setCategories(categories);
        return book;
    }

    private Author getRandomAuthor() {
        Random random = new Random();
        int randomId = random.nextInt(authorService.getAllAuthorsCount()) + 1;
        return authorService.findAuthorById(randomId);
    }

    private LocalDate getReleasedDate(String dates) {
        String[] arr = dates.split("/");
        LocalDate date = LocalDate.of(Integer.parseInt(arr[2]), Integer.parseInt(arr[1]), Integer.parseInt(arr[0]));
        return date;
    }
}